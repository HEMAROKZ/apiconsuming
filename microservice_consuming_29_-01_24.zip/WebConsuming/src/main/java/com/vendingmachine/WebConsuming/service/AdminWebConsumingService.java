package com.vendingmachine.WebConsuming.service;

import com.vendingmachine.WebConsuming.model.Inventory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class AdminWebConsumingService {

    @Autowired
    RestTemplate restTemplate;

    private static final String UPDATE_PRODUCT_BY_ID="/productsput/{id}";
    private static final String DELETE_PRODUCT_BY_ID="/products/{id}";
    private static final String CREATE_PRODUCT="/products";




    public ResponseEntity<String> addProduct(Inventory inventoryDTO){
        return restTemplate.postForEntity(CREATE_PRODUCT,inventoryDTO,String.class);
    }


    public void updateProductById(Inventory inventry,int id){
        Map<String,Integer> param=new HashMap<String, Integer>();
        param.put("id",id);
        restTemplate.put(UPDATE_PRODUCT_BY_ID,inventry,param);
    }

    public void deleteProductById(int id) {
        Map<String,Integer> param=new HashMap<String, Integer>();
        param.put("id",id);
        restTemplate.delete(DELETE_PRODUCT_BY_ID,param);
    }
}
