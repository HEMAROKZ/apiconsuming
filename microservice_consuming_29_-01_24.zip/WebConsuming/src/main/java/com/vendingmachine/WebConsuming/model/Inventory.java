//package com.vendingmachine.WebConsuming.model;
//
//public class Inventory {
//
//    public int productId;
//
//    public String name;
//
//    public int productPrice;
//
//    public int productInventryCount;
//
//
//    public Inventory() {
//    }
//
//    public Inventory(int productId, String name, int productPrice, int productInventryCount) {
//        this.productId = productId;
//        this.name = name;
//        this.productPrice = productPrice;
//        this.productInventryCount = productInventryCount;
//
//    }
//
//    public int getProductId() {
//        return productId;
//    }
//
//    public void setProductId(int productId) {
//        this.productId = productId;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public int getProductPrice() {
//        return productPrice;
//    }
//
//    public void setProductPrice(int productPrice) {
//        this.productPrice = productPrice;
//    }
//
//    public int getProductInventryCount() {
//        return productInventryCount;
//    }
//
//    public void setProductInventryCount(int productInventryCount) {
//        this.productInventryCount = productInventryCount;
//    }
//
//}
//
package com.vendingmachine.WebConsuming.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

public class Inventory implements Serializable {
    @NotNull
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private final int productId;

    private final String name;
    @NotNull
    private final int productPrice;
    @NotNull
    private final int productInventryCount;



    public Inventory(InventoryDTOBuilder inventoryDTOBuilder) {
        this.productId = inventoryDTOBuilder.productId;
        this.name = inventoryDTOBuilder.name;
        this.productPrice = inventoryDTOBuilder.productPrice;
        this.productInventryCount = inventoryDTOBuilder.productInventryCount;
    }

    public Inventory(int productId, String name, int productPrice, int productInventryCount) {
        this.productId = productId;
        this.name = name;
        this.productPrice = productPrice;
        this.productInventryCount = productInventryCount;
    }

    public static InventoryDTOBuilder builder(){
        return new InventoryDTOBuilder();
    }
    public int getProductId() {
        return productId;
    }


    public String getName() {
        return name;
    }


    public int getProductPrice() {
        return productPrice;
    }


    public int getProductInventryCount() {
        return productInventryCount;
    }

    public static class InventoryDTOBuilder {
        private  int productId;
        private  String name;
        private  int productPrice;
        private  int productInventryCount;

        public InventoryDTOBuilder() {
        }

        public InventoryDTOBuilder productId(int productId) {
            this.productId = productId;
            return this;
        }

        public InventoryDTOBuilder name(String name) {
            this.name = name;
            return this;
        }

        public InventoryDTOBuilder productPrice(int productPrice) {
            this.productPrice = productPrice;
            return this;
        }
        public InventoryDTOBuilder productInventryCount(int productInventryCount) {
            this.productInventryCount = productInventryCount;
            return this;
        }
        public Inventory build() {
            return new Inventory(this);
        }

    }
}
