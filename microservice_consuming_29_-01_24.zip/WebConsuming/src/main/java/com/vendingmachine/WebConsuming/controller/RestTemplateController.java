package com.vendingmachine.WebConsuming.controller;

import com.vendingmachine.WebConsuming.model.CustomerInputDTO;
import com.vendingmachine.WebConsuming.model.Inventory;
import com.vendingmachine.WebConsuming.service.AdminWebConsumingService;
import com.vendingmachine.WebConsuming.service.CustomerWebConsumingService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class RestTemplateController {

    @Autowired
    private AdminWebConsumingService adminWebConsumingService;

    @Autowired
    private CustomerWebConsumingService customerWebConsumingService;


    @GetMapping("/getAllProduct")
    @Operation(summary = "Consuming CUSTOMER PROCESS--Get LIST OF ALL Inventry item")
    public ResponseEntity<String> getAllProduct(){
        return customerWebConsumingService.allProduct();
    }


    @GetMapping("/getProduct/{id}")
    @Operation(summary = "Consuming CUSTOMER PROCESS--Get Inventry item by id")
    public Inventory getProductById(@PathVariable int id){
        return customerWebConsumingService.getProductById(id);
    }



    @PutMapping("/product")
    @Operation(summary = "CUSTOMER PROCESS--purchase Inventry item")
    public String   ProductPurchase(@RequestBody CustomerInputDTO customerInputDTO) {
        return customerWebConsumingService.purchaseProduct(customerInputDTO);
    }

    @PostMapping("/addProduct")
    @Operation(summary = "Consuming ADMIN PROCESS--Add  Inventory item ")
    public ResponseEntity<String> addProduct(@RequestBody Inventory inventoryDTO){
        return adminWebConsumingService.addProduct(inventoryDTO);
    }

    @PutMapping("/updateProduct/{id}")
    @Operation(summary = "Consuming ADMIN PROCESS--Update  Inventory item ")
    public String updateProductById(@RequestBody Inventory e, @PathVariable int id){
        adminWebConsumingService.updateProductById(e,id);
        return "updated !!";
    }

    @DeleteMapping("/products/{id}")
    @Operation(summary = "Consuming ADMIN PROCESS--DELETE  Inventory item ")
    public String deleteProductById(@PathVariable int id) {
        adminWebConsumingService.deleteProductById(id) ;
        return " Product deleted from the database";
    }

}
