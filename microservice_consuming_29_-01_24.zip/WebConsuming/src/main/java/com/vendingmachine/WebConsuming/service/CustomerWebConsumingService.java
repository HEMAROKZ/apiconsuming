package com.vendingmachine.WebConsuming.service;

import com.vendingmachine.WebConsuming.model.CustomerInputDTO;
import com.vendingmachine.WebConsuming.model.Inventory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Service
public class CustomerWebConsumingService {

    @Autowired
     RestTemplate restTemplate;

    private  Logger log = LoggerFactory.getLogger(CustomerWebConsumingService.class);

//
//    @Value(value = "${client.url}")
//    private  String client;
//

    private  final String GET_ALL_ITEMS="/";
    private  final String GET_PRODUCT_BY_ID="/product/{id}";
    private  final String PURCHASE_PRODUCT_BY_ID="/product";


    public  ResponseEntity<String> allProduct(){
        HttpHeaders headers=new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity=new HttpEntity<String>("parameters",headers);
        ResponseEntity<String> response= restTemplate.exchange(GET_ALL_ITEMS, HttpMethod.GET,entity, String.class);
        return response;
    }


    public  Inventory getProductById(int id){
        Map<String,Integer> param=new HashMap<String, Integer>();
        param.put("id",id);
        return restTemplate.getForObject(GET_PRODUCT_BY_ID,Inventory.class,param);
    }

//  WORKING
//    public String purchaseProduct(CustomerInputDTO customerInputDTO) {
//        int productId = customerInputDTO.getProductId();
//        int inputPrice = customerInputDTO.getPrice();
//
//        log.info("product id in purchase product == {} ",productId);
//        log.info("inputPrice in purchase product == {} ",inputPrice);
//
//        restTemplate.put(PURCHASE_PRODUCT_BY_ID,customerInputDTO);
//        return  "productId "+productId+" item has been successfully purchased";
//    }
//

    public  String purchaseProduct(CustomerInputDTO customerInputDTO) {
        int productId = customerInputDTO.getProductId();
        int inputPrice = customerInputDTO.getPrice();

        log.info("product id in purchase product == {} ",productId);
        log.info("inputPrice in purchase product == {} ",inputPrice);

        restTemplate.put(PURCHASE_PRODUCT_BY_ID,customerInputDTO);
        return  "productId "+productId+" item has been successfully purchased";
    }

}

//
//    public void purchaseProduct(CustomerInputDTO customerInputDTO) {
////        Map<String,Integer> param= new HashMap<>();
////        param.put("id",id);
////        param.put("price",price);
//
//         restTemplate.put(PURCHASE_PRODUCT_BY_ID,customerInputDTO);
////
////        HttpEntity<CustomerInputDTO> entity = new HttpEntity<>(customerInputDTO);
////        return   restTemplate.exchange(PURCHASE_PRODUCT_BY_ID, HttpMethod.PUT,entity, VendingMachineOutputDTO.class);
////
//    }

