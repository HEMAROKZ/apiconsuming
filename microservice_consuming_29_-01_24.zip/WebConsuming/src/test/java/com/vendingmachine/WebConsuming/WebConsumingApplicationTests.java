package com.vendingmachine.WebConsuming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebConsumingApplicationTests {

	@Test
	void contextLoads() {
	}

}
