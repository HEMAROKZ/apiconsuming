package com.VendingMachine.VendingMachine01.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.VendingMachine.VendingMachine01.model.Inventry;
import org.springframework.jdbc.core.RowMapper;
public class InventoryRowMapper  {

//@Override
//public Inventry mapRow(ResultSet rs, int rowNum) throws SQLException {
//    Inventry inventry = new Inventry();
//    inventry.setName(rs.getString("name"));
//    inventry.setProductInventryCount(rs.getInt("productinventrycount"));
//    inventry.setProductId(rs.getInt("productid"));
//    inventry.setProductPrice(rs.getInt("productprice"));
//        return inventry;
//        }
    }