package com.VendingMachine.VendingMachine01.service;

import com.VendingMachine.VendingMachine01.dao.InitialBalanceDAOImp;
import com.VendingMachine.VendingMachine01.dao.InventoryDAOImp;
import com.VendingMachine.VendingMachine01.dto.InventoryDTO;
import com.VendingMachine.VendingMachine01.model.Inventry;
import org.springframework.stereotype.Service;

@Service
public class AdminServices {

     private  InventoryDAOImp repository;

    public AdminServices(InventoryDAOImp repository, InitialBalanceDAOImp initialBalanceDAOImp) {
        this.repository = repository;
    }
//    public int saveInventory(Inventry.InventoryBuilder inventry){ return repository.save(inventry); }
    public int saveInventory(InventoryDTO inventry){ return repository.save(inventry); }

    public int updateInventory(Inventry inventry,int productId){
        return repository.update(inventry,productId);
    }

    public int deleteProductById(int productId){
        return repository.deleteById(productId);
    }

}
