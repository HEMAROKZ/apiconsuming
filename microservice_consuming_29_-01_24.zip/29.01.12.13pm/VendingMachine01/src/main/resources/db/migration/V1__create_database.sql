


CREATE TABLE productlist (
  productId INT NOT NULL ,
  name VARCHAR(45) NOT NULL,
  productPrice INT NOT NULL,
  productInventryCount INT NOT NULL,
  PRIMARY KEY (productId)
);

CREATE TABLE purchasehistory_table (
  id INT NOT NULL,
  productId INT NOT NULL,
  product VARCHAR(45) NOT NULL,
  productPrice INT NOT NULL,
  customerInputAmount INT NOT NULL,
  vendingMachineBalance INT NOT NULL,
  initialBalance INT NOT NULL,
  PRIMARY KEY (id));

