
INSERT INTO productlist (productId,name,productPrice,productInventryCount)
VALUES (456, 'DIET COKE', 35, 32),
              (238, 'THUMBS UP', 43, 18),
              (832, 'COLD COFFEE', 37, 12),
              (645, 'LAYS', 25, 29),
              (562, 'CHEETOS', 10, 7),
              (611, 'STRING', 32, 15);


INSERT INTO purchasehistory_table
(id,
productId,
product,
productPrice,
customerInputAmount,
vendingMachineBalance,
initialBalance)
VALUES
(1,000,'Admin_Update',0,0,0,500);



